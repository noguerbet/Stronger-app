# STRONGER PWA · Versió 0.2

## Novetats
- Check-in diari: pes corporal opcional, aigua, deposició i observacions digestives.
- Energia, hores i qualitat del son, estrès, molèsties i notes.
- Seguiment opcional del cicle menstrual i símptomes.
- Progrés i historial de força, pes i benestar.
- Importació/exportació JSON.
- Dades guardades localment al navegador.

## Instal·lació
Per provar-la, obre `index.html`. Per instal·lar-la com a PWA, publica els fitxers en un allotjament HTTPS (GitHub Pages, Netlify o Vercel) i obre l'URL al mòbil. A Android, tria «Instal·la l'aplicació» o «Afegeix a pantalla d'inici».

## Privacitat i salut
Les dades es queden al navegador del dispositiu; no hi ha sincronització ni servidor. El registre del cicle i del pes és opcional. STRONGER és una eina de seguiment i educació general, no un dispositiu mèdic ni un substitut de professionals sanitaris. Les recomanacions d'entrenament han de tenir en compte dolor, símptomes i recuperació individual.
